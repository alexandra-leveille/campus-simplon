var dataset1 = [
  {
    prenom:'Jack',
    nom:'Napier',
    genre:'personnage',
    age:null,
    icon:null,
    hobbies:['être l\'ennemi de batman', 'farces et attrapes', 'humour noir']
  },
  {
    prenom:'Lou',
    nom:'Reed',
    genre:'humain',
    age:71,
    icon:null,
    hobbies:['musique', 'be a rockstar', 'groupies']
  },
  {
    prenom:'Ada',
    nom:'Lovelace',
    genre:'humain',
    age:37,
    icon:null,
    hobbies:['inventer l\'algorithme', 'mathématiques', 'donner son nom à un langage de programmation']
  },
  {
    prenom:'Snoop',
    nom:'Dog',
    genre:'humain',
    age:44,
    icon:null,
    hobbies:['rapping', 'rolling', 'stoning']
  },
  {
    prenom:'Evelyne',
    nom:'Thomas',
    genre:'humain',
    age:60,
    icon:null,
    hobbies:['c\'est', 'ton', 'choix']
  },
  {
    nom:'Kitty',
    genre:'animal',
    espece:'chat',
    age:5,
    icon:null,
    hobbies:['lait', 'souris', 'ronron', 'sieste']
  },
  {
    nom:'Wako',
    genre:'animal',
    espece:'chien',
    age:8,
    icon:null,
    hobbies:['os', 'bâton', 'aboyer', 'sieste']
  },
  {
    nom:'Bulle',
    genre:'animal',
    espece:'poisson rouge',
    age:13,
    icon:null,
    hobbies:['tourner en rond', 'oublier', 'buller']
  }
];